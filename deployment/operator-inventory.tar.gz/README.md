# Operator Inventory

A responsive mobile and desktop web app seeded from `Operators Inventory - ALL.xlsx`. Home offers **Operating Supplies** (40 items), **Janitorial Supplies** (18 items), and **Dewatering Supplies** (14 items). Only the first three worksheets are imported; the final two order worksheets are ignored completely. Phones keep the single-column mobile interface, including in landscape. Other browsers use a wider desktop workspace at 900px and above, with sidebar navigation, multiple card columns, and centered dialogs. Narrow desktop windows use the compact interface. Detection combines phone browser identification and touch/screen information; resizing updates the layout without changing inventory data.

Under **New Inventory**, tap a worksheet, choose a date and enter your name. Each inventory contains only that worksheet's items and locations. New count fields start blank. Each card shows **Previous** from the latest completed inventory of the same worksheet (by inventory date, then completion time), where the description, count size, and location still match. Drafts are ignored as reference sources. Type today's quantity using the decimal keyboard. Previous quantities are references only; there are no arrow or copy buttons. Use the keyboard's **Next** key to move to the next item. The app fits its height to the visible screen while editing, scrolls the focused field above the keyboard, and temporarily hides the bottom navigation when the keyboard reduces the available space. The location picker stops sticking while the keyboard is open; progress counters remain at the top. A blank is uncounted; an explicitly entered zero is counted. Previous quantities alone never advance progress or satisfy completion. Existing drafts keep their saved counts; create a new inventory to use the blank-field workflow. Counts save automatically, and the completed source record remains unchanged. The top counters and compact bottom navigation stay outside the content scroll area. Items stay in worksheet order, with no search field. Completing requires every current item count. History cards offer View, Edit and confirmed Delete; View keeps completed counts read-only, while Edit allows corrections that preserve completion status and the original completion date. Corrections do not requeue the inventory as a new order-list submission. Counts at or below PAR are flagged for review; this version does not place orders.

On startup, the app permanently deletes old combined inventories from storage. Separate worksheet inventories and their counts are retained.

White Rags has no count size and its PAR is “Fill As Needed” in the workbook. The app preserves those omissions and shows a manual review status rather than inventing a numeric threshold. Inventory records include a snapshot of the catalog so historical units and PAR values remain intact when the catalog changes.

## Local use

Requires Node.js 22 or newer. Nodemailer handles SMTP; there is no frontend build step.

```powershell
cd apps/operator-inventory
npm ci
npm start
```

Open `http://localhost:3080`. Saved records are stored in `data/inventories.json`. Set `PORT` and `DATA_DIR` to override defaults. Run `npm test` for catalog and API lifecycle checks.

An optional browser check is available with `node test/mobile-browser.js`. It uses headless Chrome (set `CHROME_PATH` if needed), isolated temporary data, and checks 320/390/430px layouts, worksheet workflows, and focused-field visibility with simulated layout-resizing and overlay keyboards. This does not replace testing the actual keyboard on a physical Android device. Screenshots are saved in the ignored `preview/` folder.

## Unraid / Docker

For the step-by-step setup on 192.168.0.88 and your Nginx Proxy Manager at inventory.gibbhub.io, see [UNRAID-SETUP.md](UNRAID-SETUP.md).

This app has its own container and does not require the existing water-treatment-tools proxy, external Docker network, or API keys.

From this directory on your server:

```sh
mkdir -p /mnt/user/appdata/operator-inventory
chown 1000:1000 /mnt/user/appdata/operator-inventory
docker compose up -d --build
```

Open `http://YOUR-UNRAID-IP:3080`. The Compose file binds `/mnt/user/appdata/operator-inventory` to `/data`, so inventories survive container replacement. The image runs as Node's non-root user, UID/GID 1000; the host folder must be writable by that user.

For the Unraid Docker UI, build the image first with `docker build -t operator-inventory:latest .`, then add a container:

| Setting | Value |
| --- | --- |
| Repository | `operator-inventory:latest` |
| Network type | Bridge |
| Container port / host port | `3080` / `3080` (TCP) |
| Container path / host path | `/data` / `/mnt/user/appdata/operator-inventory` |
| WebUI | `http://[IP]:[PORT:3080]/` |
| Timezone | `TZ=America/Denver` |

Back up the appdata folder. Use one container instance for this data directory; writes are atomic and concurrent edits to the same draft are rejected using revision checks. On a conflict, the UI keeps the unsaved values visible for reference and asks you to reload the latest version. On a storage/network error, retry saving before leaving. This initial version has no login and is intended for your trusted local network.

## Refreshing the catalog

On Windows, re-run the included importer and rebuild the container:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File ./import-workbook.ps1 -Workbook 'C:\path\Operators Inventory - ALL.xlsx'
```

The importer reads workbook values and external product hyperlinks, carries merged location headings down their item rows, and preserves descriptions, count sizes, PAR, supplier, item number, and case size. Existing inventory snapshots stay unchanged.

## Order Needed report

Completing an inventory opens its Order Needed report automatically. Each card in History and Recent inventories also has a report button, including a clearly labeled draft report for unfinished counts. The report uses the saved inventory's item details and counts, so later catalog changes do not alter historical results.

Items with entered quantities at or below their numeric PAR are listed in worksheet order with location, on-hand quantity, PAR, count size, and supplier details. Blank counts are excluded and draft reports show how many items remain uncounted. Items with nonnumeric rules such as Fill As Needed appear separately under Review as needed. PAR is a trigger, so the report does not calculate an order quantity or send orders.

## Email reports

Each Order Needed report has a recipient field and Send report by email button. Set `SMTP_USER` and `SMTP_PASSWORD` in the Unraid source folder's `.env` and recreate the container to enable it. Defaults are Namecheap Private Email (`mail.privateemail.com`, TLS on port 465); port 587 requires STARTTLS. `EMAIL_DEFAULT_TO` can prefill a recipient. See [the email setup instructions](UNRAID-SETUP.md#optional-email-order-needed-reports).

The server builds the email from saved inventory counts and snapshots. The HTML version uses a table with item, location, on-hand quantity, PAR, count size, and supplier/product details; manual-review items have a separate table with their rule. Product numbers link to the saved product page when an HTTP or HTTPS link is available; otherwise they remain plain text. Approved item photos appear beneath the item name as embedded inline attachments, so recipients do not need access to the inventory app. Items without photos keep text-only rows. Email clients may hide images or lack support for some image formats. It also includes a plain-text version, marks drafts clearly, and never sends automatically. Invalid addresses and stale reports are rejected, and sends are limited to one every 30 seconds. SMTP credentials are kept out of the browser, Git, and Docker image. Success indicates SMTP acceptance; verify actual delivery in the recipient inbox. Local SMTP use requires environment variables supplied by your shell; `npm start` does not load `.env` itself. Tests use mock senders and do not send actual email.

## Deleting inventories

History and Recent inventories include a trash button for each draft or completed inventory. A confirmation popup identifies the worksheet, date, and operator before permanent deletion. Cancel keeps the record. Deleted completed inventories are excluded from previous-count references for future inventories; existing inventories retain their saved reference snapshots. If a record changes after confirmation opens, reopen the popup to review it before deleting.

## Unfinished Inventories

Only one new unfinished inventory is allowed per worksheet type. Selecting a type with an existing draft resumes it, preserving its date, operator, and counts. The server also enforces this for concurrent starts. Older duplicate drafts remain available until explicitly completed or deleted. Chemical Inventory now autosaves drafts and appears in the main page's inventory list with Resume, View Report, and explicit completion; see [chemical inventory](../../docs/chemical-inventory.md).

## Product photo preview

Product photos are enabled. The UI displays only photos tagged `workbook-link` or `user-provided` in the image manifest. Photos found through additional product-number searches remain stored but hidden.

The current bundle displays 40 photos for Operating Supplies: 18 from the original workbook-link import and user-selected photos for Methyl Purple Indicator, pH 7.00 Buffer, pH 10.01 Buffer, Sulfuric Acid, 0.02N, EDTA Titrant 0.01M, Large 3 mil gloves, XL 3 mil gloves, Kim Wipes, Waffle Print Tissues, Sulfuric Acid Dropper Bottle 5.25N, Alkaline Cyanide Reagent, Salt Bridge Solution, RoVer Rust Remover, Salt Bridge for DPD1P1 PEEK, CL-17 Colorimeter (analyzer reference photo), Crush Tube Large, Crush Tube Small, Black 5 mil Nitrile Gloves LG, Black 5 mil Nitrile Gloves XL (shared glove reference photos), Hydrogen Peroxide, Vinegar, and the 10-inch Filter Cartridge. Two additional search results remain hidden. Compact thumbnails appear next to the item name; tapping one opens its product page. Items without an approved photo keep their normal card layout. Photos do not fill counts or affect progress, and existing drafts can display photos when their name and item number match the catalog.

The workbook contains 37 product links across its first three sheets, and none for Janitorial Supplies. Some links are obsolete or block automated requests. The user confirmed 5.25 N for the acid dropper item and supplied its packaging photo. Its thumbnail opens that selected image rather than the workbook link, which describes 19.2 N. The user explicitly selected the supplier packaging photo for Alkaline Cyanide Reagent after reviewing its different bottle label. Supplier packaging can change; photos are a reference and may show a product family.

To refresh photos from the imported catalog, run this locally with Node 22 or newer and internet access:

```sh
node scrape-images.js
```

The importer checks product metadata, downloads supported raster images into `public/images/`, and records product page, image URL, item number, source type, and download date in `public/images/manifest.json`. It also checks additional supplier pages listed by item number in `image-sources.json` and Northwest Scientific's catalog-number lookup, independently of workbook links; those results are tagged `additional-search` and hidden. Existing downloads are retained; unsuccessful links and items without links are recorded in `image-import-report.json`. It makes at most two concurrent requests and does not run while staff count inventory. Rebuild the container after importing images. The Docker image includes the photo files; no image API keys or external image requests are needed by phones.

To add a user-selected direct image link, identify the item's ID in `catalog.json`, then run:

```sh
node import-image.js s1-r5 'https://example.com/product-photo.jpg'
```

This replaces that item's photo, validates the image format and size, and tags it `user-provided` so it appears in the UI. Use a direct JPEG, PNG, WebP, or GIF link rather than a product page.

## Appearance

Typography and the header Apps menu use the shared [Operations design system](../../docs/operations-design-system.md). Inter is hosted locally, and the menu provides links back to Operations Home and the other tools. Switching apps uses inventory's existing save/validation flow; invalid or conflicting counts prevent navigation. Theme assets are synchronized from `shared/operations/` during deployment.

The UI uses a high-contrast light design with white surfaces, dark text, restrained Northglenn teal (#00677F), and a dark navigation dock. Operations and Janitorial use the existing Phosphor Regular gauge and broom icons (MIT license included in public/licenses). Dewatering uses the selected matching custom rotary fan press outline inspired by the provided equipment photo. Neutral cards keep product photos and quantities easy to read.

## Manage inventory items

Open Management, choose Manage items, and choose a worksheet. Edit an existing item, or tap Add item. Enter a name, location (select an existing location for the worksheet, or choose Add new location and enter its name), and count size. PAR accepts decimals; leave it blank for manual replenishment review. Supplier, product number, pack size, replenishment note, and product-page link are optional. Remove asks for confirmation. New items appear at the end of the worksheet catalog, grouped by their location during counting.

Changes apply to new inventories only. Existing drafts, completed inventories, counts, and order reports retain their saved item snapshots. Item changes are saved in /data/inventories.json alongside inventory records, so the existing Unraid volume preserves them through container rebuilds. After the first edit, the saved catalog takes precedence over the bundled workbook catalog. Back up this data file to preserve both counts and item settings.

Anyone who can access the app can manage items; separate administrator accounts have not been added. Renaming an item retains its photo while the item ID and product number match. Changing the product number hides a mismatched photo; items without a usable product number still require a matching name. Photo uploads are not part of this screen yet.

The header uses the supplied City of Northglenn horizontal logo on a white background, with Water Treatment Facility identification. The original logo is stored in public/branding/northglenn-logo.png and included in the Docker image.

## Automated deployment

The repository-wide entry point is now `powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\deploy.ps1 -Target Inventory` from the repository root. Omit `-Target Inventory` to update both containers. It calls this app's existing deployer; source/data paths and the inventory URL are unchanged. See [shared deployment instructions](../../docs/deployment.md).

Run `powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\apps\operator-inventory\deploy.ps1` from the repository root to test, package, upload, and rebuild on Unraid. Add `-PackageOnly` to package without contacting the server. See UNRAID-SETUP.md for prerequisites and backup behavior.

## Ordering backlog

Add item on the Order List opens a shared catalog picker with search by item name, product number, or supplier. It accepts any configured catalog item regardless of PAR or whether an inventory exists. Quantity may be left blank for later; units and notes save with the entry. Duplicate pending items are disabled in the picker and rejected by the API. These additions have a manual source, without inventing an on-hand count or inventory date.

Each order in Order History also has Add item, using the same picker. This records a missing purchase on that existing order and requires a positive quantity purchased. Existing order date, buyer, and reference are retained, and an update timestamp is recorded. It does not submit a purchase, change inventory, or alter the active backlog. Duplicate line items on the same recorded order are rejected. Both actions use shared revision checks to prevent overwriting another browser's changes.

The dock includes a separate Order History screen (shipping-box icon). Delete order asks for confirmation and removes only the recorded order, without restoring items to the active backlog or altering inventory history.

For an explicit full history reset on Unraid, run `bash /mnt/user/appdata/operator-inventory-source/reset-unraid.sh` after deploying. This stops the app, backs up inventories.json inside the data volume's backups folder, clears inventory runs, the pending order list, order history, and processed inventory references, then restarts and verifies the app. Catalog item configurations and catalog revision are preserved; photos, product links, environment settings, and email configuration are not removed. Resets are never run automatically during deployment or startup.

Completing an inventory automatically adds every counted item at or below numeric PAR to the shared Order List. Drafts do not add items automatically. On upgrade, the latest completed inventory for each worksheet fills the backlog; obsolete older reports do not add old needs. Manual-review items with no numeric PAR still need an explicit Add to List decision because the app cannot infer whether they need purchasing.

The backlog is grouped by the saved product-page destination when available (HACH, VWR/Avantor, Amazon, or the linked domain). Entries without a link use their existing supplier label. The links remain the purchasing destinations. Repeated low-stock items update their inventory reference while retaining the same backlog entry, quantity, purchasing unit, notes, and original added date. Items remain pending until staff mark them ordered or explicitly remove them; a later above-PAR count does not silently remove a deferred purchase.

Check Ordering now on the items being purchased. Selection is local to the current page session, so unselected suppliers can remain in the backlog for weeks. Edit order details sets the purchase quantity, purchasing unit, and notes; quantities begin blank and are never inferred from PAR. The purchase unit may differ from the counting unit, with no automatic conversion. Review selected (globally or within a supplier) creates a checklist for only those items. Print / Save PDF is available once all selected items have quantities; phones use stacked review details and printing uses a table. Printing does not submit or record an order.

After placing a purchase, Mark selected ordered asks for date, name, and an optional order reference. Confirmation atomically moves only those selected items into Ordered history. Unselected items stay in the backlog with their notes and quantities. Recorded orders retain item snapshots, links, quantities, and source inventory details. Restarting does not re-add the same processed inventory's purchases. A later completed inventory can flag the item again; receiving and shipment tracking are not implemented.

The backlog, processed inventory IDs, and ordered history are saved with inventories in inventories.json and included in existing Docker volume backups. Revision checks prevent stale edits and duplicate order confirmations from overwriting another phone's changes. No inventory counts are changed by ordering actions.

## Management and printed bin cards

Open **Management** from the navigation tab. **Manage items** retains the worksheet picker and add/edit/remove actions. Operating Supplies items also have **Print card** for replacing one label. Janitorial and Dewatering items do not have printing actions.

**Print bin cards** lists only current Operating Supplies items. Search by name, supplier, or product number; check individual items, **Select all**, or **Clear selection**. Searching preserves selections outside the filtered results. Select all selects the whole Operating Supplies worksheet. **Preview & print selected** opens a separate preview using the latest saved catalog details, without creating an inventory or changing counts. Printing is restricted to current Operating Supplies items even if the preview URL contains other item IDs. Deleted or moved items are omitted with a warning.

Cards use the approved option 4 layout at **4 × 1¾ inches**, with the larger photo at left, supplier/product number/PAR in the middle, and product QR at right. PAR includes its counting unit; there is no separate count-size field. Pack details stay on one line, using extra width below the photo when needed. Approved local product photos are used only while their identity matches the current item. Missing photos, product numbers, supplier details, pack sizes, or product links are flagged; missing photos and links receive placeholders. QR codes are generated locally with the bundled MIT-licensed library; no third-party QR service receives product information. Amazon tracking is removed while retaining the same product identifier.

Review the preview, then use **Print / Save PDF**. Six cards fit each landscape Letter sheet. Print at **100% / Actual size**, disable browser headers/footers, and cut along the card borders. Each sheet includes a 1-inch scale check. Test an insert and QR scanning through the physical holder before printing a batch. **Refresh saved details** reloads catalog edits in an already-open preview. Text that cannot fit is flagged and disables the print button until corrected; no text is silently truncated.

Run `node test/bin-card-browser.js` for the optional headless Chrome integration check covering management navigation, selection, individual/batch previews, latest saved edits, card dimensions, print styles, and worksheet restrictions. It uses isolated temporary data; screenshots go to the ignored `preview/` folder.

## Pack-size convention

Inventory entry asks staff to double-check unusually large changes from the previous completed inventory before saving. A change must be at least two count units and either reach three times the previous count, drop to one quarter or less, or rise from zero to at least ten. Missing previous counts do not trigger a prompt. The check waits until staff leave the field, and offers Use this count or Edit count. Confirmation applies only to the entered value; changing it triggers a fresh check. This is an entry safeguard, not an ordering rule.

Pack labels use contents / package, such as 500 mL / bottle, 10 L / cubetainer, 10 boxes / case (250 gloves / box; 2,500 total), and 10 tubes / pack. Volumes use mL or L, weights use g, package names are lowercase, and large quantities use commas. Single-piece supplies use 1 plus the item type. Counting quantities, PAR levels, and counts are preserved; a supplier pack is not automatically treated as a counted case. Missing worksheet pack sizes remain unspecified.

The reviewed labels are shared by the catalog API, item editor, inventory cards, order reports, and email reports. They also format old snapshots for display without rewriting saved inventory records. Only exact reviewed workbook values for matching items are formatted; custom pack-size edits take precedence. Original workbook values and source/review notes are in pack-size-review.json. The user confirmed Cubetainer for the 4 L buffers, 0.02N sulfuric acid, and EDTA; 2,500 gloves per Large case (250 per box) and 2,250 per XL case (225 per box); and a 1 L bottle for 5.25N sulfuric acid. Single-container count label changes preserve previous-count references and never convert quantities. The user confirmed one box contains 20 buffer singlets. Its count unit is Box, to distinguish a full box from an individual singlet packet. Previous Case and Pack labels retain their count references.

## Chemical Inventory

The home worksheet list includes a separate Chemical Inventory section with numeric tank levels, gallons on hand, salt pallets, and the Northwest Open Space water totalizer. It uses the October 21, 2026 workbook formulas. East permanganate is monitored as a 10% batch and excluded from the 20% inventory total. Readings can be saved partially, reviewed by date, edited, and deleted. Chemical deliveries and consumption are not tracked in this version.

See [Chemical Inventory Documentation](../../docs/chemical-inventory.md) for formulas, units, storage, and validation. The chemical records use the existing persistent inventory data file and normal inventory deployment.

## Chemical Settings

Management now separates Supply Items, Bin Cards and Chemical Settings. Search supply items by name, supplier or product number and filter by location. Chemical Settings supports ordering defaults, tank capacities and calibration factors, with an example calculation preview before saving. Each save creates an effective-dated version with an operator and change summary. New inventories use the applicable version; existing drafts and completed records retain their calculations. Imported workbook gallon snapshots remain unchanged.
